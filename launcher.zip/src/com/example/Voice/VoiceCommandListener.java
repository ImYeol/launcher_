package com.example.Voice;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

import com.example.Voice.VoiceListenerService.VoiceListenerBinder;

public class VoiceCommandListener  {


}
