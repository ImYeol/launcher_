package com.example.Voice;

public class SpeechCommandList {
	public static final String FILTER="com.example.glasstest";
	public static final String OPEN="open";
}
